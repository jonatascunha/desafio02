
public class Metodo {
    public static void main(String[] args) {

        Metodo2 map = new Metodo2();
        map.returnMap();
    }
}
